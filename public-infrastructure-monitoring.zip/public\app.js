const assetRows = document.querySelector('#asset-rows');
const searchInput = document.querySelector('#search-input');
const typeFilter = document.querySelector('#type-filter');
const statusFilter = document.querySelector('#status-filter');
const toast = document.querySelector('#toast');
let toastTimer;
let visibleAssets = [];

const escapeHtml = (value) => String(value).replace(/[&<>"']/g, (char) => ({
  '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
})[char]);

function statusClass(status) {
  return status.toLowerCase().replace(/\s+/g, '-');
}

function renderAssets(assets, totalAssets) {
  visibleAssets = assets;
  document.querySelector('#result-count').textContent = `Showing ${assets.length} of ${totalAssets} assets`;
  document.querySelector('#nav-count').textContent = String(assets.length).padStart(2, '0');
  if (!assets.length) {
    const message = totalAssets ? 'No assets match those filters.' : 'The asset registry is empty.';
    assetRows.innerHTML = `<tr><td colspan="6" class="loading-cell">${message}</td></tr>`;
    return;
  }

  assetRows.innerHTML = assets.map((asset) => {
    const level = asset.condition < 50 ? 'low' : asset.condition < 75 ? 'medium' : '';
    const icon = { Bridge: 'BR', Road: 'RD', Water: 'WT', Power: 'PW' }[asset.type] || 'AS';
    return `<tr>
      <td><div class="asset-name"><span class="asset-type-icon ${escapeHtml(asset.type.toLowerCase())}">${icon}</span><span class="asset-name-text"><strong>${escapeHtml(asset.name)}</strong><span>${escapeHtml(asset.id)}</span></span></div></td>
      <td><span class="type-label">${escapeHtml(asset.type)}</span></td>
      <td>${escapeHtml(asset.location)}</td>
      <td><div class="condition-cell"><span class="condition-track"><span class="condition-fill ${level}" style="width:${asset.condition}%"></span></span><span class="condition-value">${asset.condition}%</span></div></td>
      <td><span class="status-badge ${statusClass(asset.status)}">${escapeHtml(asset.status)}</span></td>
      <td><button class="row-action" data-asset-id="${escapeHtml(asset.id)}" aria-label="View ${escapeHtml(asset.name)} details" title="View details">···</button></td>
    </tr>`;
  }).join('');
}

async function loadAssets() {
  const params = new URLSearchParams();
  if (typeFilter.value !== 'All types') params.set('type', typeFilter.value);
  if (statusFilter.value !== 'All statuses') params.set('status', statusFilter.value);
  if (searchInput.value.trim()) params.set('q', searchInput.value.trim());
  assetRows.innerHTML = '<tr><td colspan="6" class="loading-cell">Loading city assets...</td></tr>';
  try {
    const response = await fetch(`/api/assets?${params}`);
    if (!response.ok) throw new Error('Unable to load assets');
    const result = await response.json();
    renderAssets(result.data, result.total);
  } catch {
    assetRows.innerHTML = '<tr><td colspan="6" class="loading-cell">Could not connect to the API. Start the server and refresh.</td></tr>';
  }
}

async function loadSummary() {
  try {
    const response = await fetch('/api/summary');
    if (!response.ok) throw new Error('Unable to load summary');
    const summary = await response.json();
    document.querySelector('#total-assets').textContent = String(summary.totalAssets).padStart(2, '0');
    document.querySelector('#good-assets').textContent = String(summary.good).padStart(2, '0');
    document.querySelector('#attention-assets').textContent = String(summary.atRisk).padStart(2, '0');
    document.querySelector('#critical-assets').textContent = String(summary.critical).padStart(2, '0');
    document.querySelector('#good-percent').textContent = summary.totalAssets
      ? `${Math.round(summary.good / summary.totalAssets * 100)}% of network`
      : 'No assets tracked';
    document.querySelector('#average-condition').textContent = summary.averageCondition;
    document.querySelector('#score-ring').style.background = `conic-gradient(#4d9676 0 ${summary.averageCondition}%, #e8eee8 ${summary.averageCondition}% 100%)`;
    document.querySelector('#queue-count').textContent = summary.critical + summary.atRisk;
  } catch {
    showToast('Could not load the monitoring summary.');
  }
}

async function loadSidebars() {
  try {
    const response = await fetch('/api/assets');
    const { data: assets } = await response.json();
    if (!assets.length) {
      document.querySelector('#attention-list').innerHTML = '<div class="loading-cell">No active asset alerts.</div>';
      document.querySelector('#inspection-list').innerHTML = '<div class="loading-cell">No inspections scheduled.</div>';
      return;
    }
    const attention = assets.filter((asset) => asset.status !== 'Good').sort((a, b) => a.condition - b.condition).slice(0, 3);
    document.querySelector('#attention-list').innerHTML = attention.map((asset) => `
      <div class="attention-item"><span class="attention-indicator ${asset.status === 'At risk' ? 'at-risk' : ''}"></span><span class="attention-copy"><strong>${escapeHtml(asset.name)}</strong><span>${escapeHtml(asset.notes)}</span></span><span class="attention-id">${escapeHtml(asset.id)}</span></div>`).join('');
    const upcoming = [...assets].sort((a, b) => a.nextInspection.localeCompare(b.nextInspection)).slice(0, 3);
    document.querySelector('#inspection-list').innerHTML = upcoming.map((asset) => {
      const date = new Date(`${asset.nextInspection}T12:00:00`);
      return `<div class="inspection-item"><span class="date-chip"><span>${date.toLocaleDateString('en-US', { month: 'short' }).toUpperCase()}</span><strong>${date.getDate()}</strong></span><span class="inspection-copy"><strong>${escapeHtml(asset.name)}</strong><span>${escapeHtml(asset.type)} · ${escapeHtml(asset.location)}</span></span></div>`;
    }).join('');
  } catch {
    document.querySelector('#attention-list').innerHTML = '<div class="loading-cell">Unable to load alerts.</div>';
  }
}

async function openAssetDetails(id) {
  try {
    const response = await fetch(`/api/assets/${encodeURIComponent(id)}`);
    if (!response.ok) throw new Error('Asset not found');
    const { data: asset } = await response.json();
    document.querySelector('#dialog-content').innerHTML = `
      <span class="dialog-kicker">${escapeHtml(asset.id)} · ${escapeHtml(asset.type.toUpperCase())}</span>
      <h2 class="dialog-title">${escapeHtml(asset.name)}</h2>
      <p class="dialog-location">${escapeHtml(asset.location)} · ${escapeHtml(asset.coordinates)}</p>
      <div class="dialog-grid">
        <div class="dialog-field"><span>CONDITION</span><strong>${asset.condition}%</strong></div>
        <div class="dialog-field"><span>STATUS</span><strong>${escapeHtml(asset.status)}</strong></div>
        <div class="dialog-field"><span>LAST INSPECTION</span><strong>${escapeHtml(asset.lastInspection)}</strong></div>
        <div class="dialog-field"><span>NEXT INSPECTION</span><strong>${escapeHtml(asset.nextInspection)}</strong></div>
        <div class="dialog-field" style="grid-column:1/-1"><span>RESPONSIBLE DEPARTMENT</span><strong>${escapeHtml(asset.owner)}</strong></div>
      </div><div class="dialog-notes">${escapeHtml(asset.notes)}</div>`;
    document.querySelector('#asset-dialog').showModal();
  } catch {
    showToast('Unable to load asset details.');
  }
}

function showToast(message) {
  toast.textContent = message;
  toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove('show'), 2600);
}

function exportReport() {
  const headers = ['ID', 'Name', 'Type', 'Location', 'Condition', 'Status', 'Last inspection', 'Next inspection', 'Owner'];
  const rows = visibleAssets.map((asset) => [asset.id, asset.name, asset.type, asset.location, asset.condition, asset.status, asset.lastInspection, asset.nextInspection, asset.owner]);
  const csv = [headers, ...rows].map((row) => row.map((field) => `"${String(field).replace(/"/g, '""')}"`).join(',')).join('\r\n');
  const link = document.createElement('a');
  link.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
  link.download = 'metro-district-assets.csv';
  link.click();
  URL.revokeObjectURL(link.href);
  showToast('Asset report exported.');
}

let searchTimer;
searchInput.addEventListener('input', () => {
  clearTimeout(searchTimer);
  searchTimer = setTimeout(loadAssets, 180);
});
typeFilter.addEventListener('change', loadAssets);
statusFilter.addEventListener('change', loadAssets);
assetRows.addEventListener('click', (event) => {
  const button = event.target.closest('[data-asset-id]');
  if (button) openAssetDetails(button.dataset.assetId);
});
document.querySelector('#dialog-close').addEventListener('click', () => document.querySelector('#asset-dialog').close());
document.querySelector('#refresh-button').addEventListener('click', () => {
  loadAssets(); loadSummary(); loadSidebars();
  document.querySelector('#footer-time').textContent = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  showToast('Monitoring data refreshed.');
});
document.querySelector('#export-button').addEventListener('click', exportReport);
document.querySelector('#view-all-button').addEventListener('click', () => {
  typeFilter.value = 'All types'; statusFilter.value = 'All statuses'; searchInput.value = ''; loadAssets();
});
document.querySelector('#inspection-filter').addEventListener('click', () => {
  typeFilter.value = 'All types'; statusFilter.value = 'All statuses'; searchInput.value = ''; loadAssets();
  document.querySelector('#assets').scrollIntoView({ behavior: 'smooth' });
});
searchInput.addEventListener('keydown', (event) => {
  if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k') event.preventDefault();
});
document.addEventListener('keydown', (event) => {
  if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k') {
    event.preventDefault(); searchInput.focus();
  }
});
document.querySelector('#current-date').textContent = new Date().toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' }).toUpperCase();

async function apiRequest(url, options = {}) {
  const response = await fetch(url, {
    ...options,
    headers: options.body && !(options.body instanceof FormData)
      ? { 'Content-Type': 'application/json', ...options.headers }
      : options.headers
  });
  const result = await response.json();
  if (!response.ok) throw new Error(result.error || 'Something went wrong. Please try again.');
  return result;
}

function showFormError(selector, message = '') {
  document.querySelector(selector).textContent = message;
}

function selectAuthRole(role) {
  document.querySelectorAll('[data-auth-role]').forEach((tab) => {
    const active = tab.dataset.authRole === role;
    tab.classList.toggle('active', active);
    tab.setAttribute('aria-selected', String(active));
  });
  document.querySelector('#public-auth-panel').hidden = role !== 'public';
  document.querySelector('#admin-auth-panel').hidden = role !== 'admin';
}

function selectPublicAuthView(view) {
  const registering = view === 'register';
  document.querySelector('#public-login-form').hidden = registering;
  document.querySelector('#public-register-form').hidden = !registering;
  document.querySelector('#public-auth-title').textContent = registering ? 'Create your account' : 'Welcome back';
  document.querySelector('#public-auth-subtitle').textContent = registering
    ? 'Create a public account to submit and track local issues.'
    : 'Sign in to report and follow a local issue.';
  document.querySelector('#public-auth-switch').innerHTML = registering
    ? 'Already have an account? <button type="button" data-auth-view="login">Sign in</button>'
    : 'New to CivicScope? <button type="button" data-auth-view="register">Create an account</button>';
  showFormError('#public-login-error');
  showFormError('#public-register-error');
}

async function showSignedInView(user) {
  document.querySelector('#auth-gate').hidden = true;
  const isAdmin = user.role === 'admin';
  document.querySelector('#admin-app').hidden = !isAdmin;
  document.querySelector('#public-portal').hidden = isAdmin;
  if (isAdmin) {
    document.querySelector('#account-name').textContent = user.name;
    document.querySelector('#account-role').textContent = user.email;
    document.querySelector('.avatar').textContent = user.name.split(/\s+/).slice(0, 2).map((part) => part[0]).join('').toUpperCase();
    loadAssets();
    loadSummary();
    loadSidebars();
    loadAdminReports();
  } else {
    document.querySelector('#public-user-name').textContent = user.name;
    loadPublicReports();
  }
}

async function signIn(form, role, errorSelector) {
  const values = Object.fromEntries(new FormData(form));
  try {
    const result = await apiRequest('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ ...values, role })
    });
    showSignedInView(result.user);
  } catch (error) {
    showFormError(errorSelector, error.message);
  }
}

async function loadPublicReports() {
  const list = document.querySelector('#my-reports');
  try {
    const result = await apiRequest('/api/reports');
    document.querySelector('#my-report-count').textContent = result.total;
    if (!result.data.length) {
      list.innerHTML = '<div class="empty-report-state">Your submitted reports will show up here.</div>';
      return;
    }
    list.innerHTML = result.data.map((report) => `
      <article class="my-report-item"><div class="my-report-top"><span class="report-category">${escapeHtml(report.category)}</span><span class="report-state ${statusClass(report.status)}">${escapeHtml(report.status)}</span></div><h3>${escapeHtml(report.title)}</h3><p>${escapeHtml(report.location)}</p>${report.photoName ? `<img class="report-photo-thumb" src="/api/reports/${encodeURIComponent(report.id)}/photo" alt="Photo attached to ${escapeHtml(report.title)}" loading="lazy">` : ''}<div class="my-report-meta"><span>${escapeHtml(report.id)}</span><span>${new Date(report.submittedAt).toLocaleDateString()}</span></div></article>`).join('');
  } catch (error) {
    list.innerHTML = `<div class="empty-report-state">${escapeHtml(error.message)}</div>`;
  }
}

async function loadAdminReports() {
  const list = document.querySelector('#admin-report-list');
  try {
    const result = await apiRequest('/api/reports');
    const openCount = result.data.filter((report) => report.status !== 'Resolved').length;
    document.querySelector('#open-report-count').textContent = openCount;
    document.querySelector('#report-nav-count').textContent = result.total;
    if (!result.data.length) {
      list.innerHTML = '<div class="empty-report-state">No public reports have been submitted yet.</div>';
      return;
    }
    list.innerHTML = result.data.map((report) => `
      <article class="admin-report-item"><div class="admin-report-main"><div class="admin-report-top"><span class="report-id">${escapeHtml(report.id)}</span><span class="report-category">${escapeHtml(report.category)}</span><span class="admin-report-date">${new Date(report.submittedAt).toLocaleString()}</span></div><h3>${escapeHtml(report.title)}</h3><p class="admin-report-location">${escapeHtml(report.location)}</p><p class="admin-report-description">${escapeHtml(report.description)}</p>${report.photoName ? `<a class="admin-report-photo-link" href="/api/reports/${encodeURIComponent(report.id)}/photo" target="_blank" rel="noopener"><img class="report-photo-thumb admin-photo-thumb" src="/api/reports/${encodeURIComponent(report.id)}/photo" alt="Photo attached to ${escapeHtml(report.title)}" loading="lazy"><span>Open full-size photo ↗</span></a>` : ''}<p class="reporter-line">Submitted by <strong>${escapeHtml(report.reporterName)}</strong> · ${escapeHtml(report.reporterEmail)}</p></div><div class="report-status-actions"><label class="report-status-control"><span>STATUS</span><select data-report-status="${escapeHtml(report.id)}" aria-label="Update status for ${escapeHtml(report.id)}"><option${report.status === 'New' ? ' selected' : ''}>New</option><option${report.status === 'In progress' ? ' selected' : ''}>In progress</option><option${report.status === 'Resolved' ? ' selected' : ''}>Resolved</option></select></label>${report.status === 'Resolved' ? `<button class="delete-report-button" type="button" data-delete-report="${escapeHtml(report.id)}" aria-label="Delete completed report ${escapeHtml(report.id)}" title="Delete completed report">Delete</button>` : ''}</div></article>`).join('');
  } catch (error) {
    list.innerHTML = `<div class="empty-report-state">${escapeHtml(error.message)}</div>`;
  }
}

async function initializeApp() {
  try {
    const result = await apiRequest('/api/session');
    if (result.user) await showSignedInView(result.user);
  } catch {
    document.querySelector('#auth-gate').hidden = false;
  }
}

document.querySelectorAll('[data-auth-role]').forEach((tab) => {
  tab.addEventListener('click', () => selectAuthRole(tab.dataset.authRole));
});
document.querySelector('#public-auth-switch').addEventListener('click', (event) => {
  const button = event.target.closest('[data-auth-view]');
  if (button) selectPublicAuthView(button.dataset.authView);
});
document.querySelector('#public-login-form').addEventListener('submit', (event) => {
  event.preventDefault();
  signIn(event.currentTarget, 'public', '#public-login-error');
});
document.querySelector('#admin-login-form').addEventListener('submit', (event) => {
  event.preventDefault();
  signIn(event.currentTarget, 'admin', '#admin-login-error');
});
document.querySelector('#public-register-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  const values = Object.fromEntries(new FormData(form));
  try {
    const result = await apiRequest('/api/auth/register', { method: 'POST', body: JSON.stringify(values) });
    await showSignedInView(result.user);
  } catch (error) {
    showFormError('#public-register-error', error.message);
  }
});
document.querySelector('#public-report-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  const formData = new FormData(form);
  if (!document.querySelector('#report-photo').files.length) formData.delete('photo');
  try {
    await apiRequest('/api/reports', { method: 'POST', body: formData });
    form.reset();
    if (photoPreviewUrl) URL.revokeObjectURL(photoPreviewUrl);
    photoPreviewUrl = null;
    document.querySelector('#photo-preview').hidden = true;
    document.querySelector('#photo-preview').innerHTML = '';
    showFormError('#report-form-error');
    await loadPublicReports();
    showToast('Your report has been sent to city services.');
  } catch (error) {
    showFormError('#report-form-error', error.message);
  }
});
let photoPreviewUrl;
document.querySelector('#report-photo').addEventListener('change', (event) => {
  const preview = document.querySelector('#photo-preview');
  const file = event.currentTarget.files[0];
  if (photoPreviewUrl) URL.revokeObjectURL(photoPreviewUrl);
  if (!file) {
    preview.hidden = true;
    preview.innerHTML = '';
    return;
  }
  photoPreviewUrl = URL.createObjectURL(file);
  preview.innerHTML = `<img src="${photoPreviewUrl}" alt="Selected area photo preview"><span>${escapeHtml(file.name)}</span><button type="button" class="remove-photo-button">Remove</button>`;
  preview.hidden = false;
});
document.querySelector('#photo-preview').addEventListener('click', (event) => {
  if (!event.target.closest('.remove-photo-button')) return;
  document.querySelector('#report-photo').value = '';
  if (photoPreviewUrl) URL.revokeObjectURL(photoPreviewUrl);
  photoPreviewUrl = null;
  event.currentTarget.hidden = true;
  event.currentTarget.innerHTML = '';
});
document.querySelector('#admin-report-list').addEventListener('change', async (event) => {
  const select = event.target.closest('[data-report-status]');
  if (!select) return;
  try {
    await apiRequest(`/api/reports/${encodeURIComponent(select.dataset.reportStatus)}`, {
      method: 'PATCH',
      body: JSON.stringify({ status: select.value })
    });
    await loadAdminReports();
    showToast('Report status updated.');
  } catch (error) {
    showToast(error.message);
    loadAdminReports();
  }
});
document.querySelector('#admin-report-list').addEventListener('click', async (event) => {
  const button = event.target.closest('[data-delete-report]');
  if (!button) return;
  const report = button.closest('.admin-report-item');
  const title = report.querySelector('h3').textContent;
  if (!window.confirm(`Delete completed report "${title}"? This cannot be undone.`)) return;
  button.disabled = true;
  try {
    await apiRequest(`/api/reports/${encodeURIComponent(button.dataset.deleteReport)}`, { method: 'DELETE' });
    await loadAdminReports();
    showToast('Completed report deleted.');
  } catch (error) {
    button.disabled = false;
    showToast(error.message);
  }
});
document.querySelectorAll('[data-signout]').forEach((button) => {
  button.addEventListener('click', async () => {
    try { await apiRequest('/api/auth/logout', { method: 'POST' }); } catch { /* Continue to sign-in if the session has expired. */ }
    document.querySelector('#admin-app').hidden = true;
    document.querySelector('#public-portal').hidden = true;
    document.querySelector('#auth-gate').hidden = false;
    selectAuthRole('public');
    selectPublicAuthView('login');
  });
});

initializeApp();
