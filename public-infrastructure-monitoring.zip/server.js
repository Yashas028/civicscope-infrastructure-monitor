const express = require('express');
const session = require('express-session');
const FileStore = require('session-file-store')(session);
const { rateLimit } = require('express-rate-limit');
const multer = require('multer');
const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');

const app = express();
const PORT = process.env.PORT || 3000;
const isProduction = process.env.NODE_ENV === 'production';
const dataDirectory = process.env.DATA_DIRECTORY || path.join(__dirname, 'data');
const assetsPath = path.join(dataDirectory, 'assets.json');
const usersPath = path.join(dataDirectory, 'users.json');
const reportsPath = path.join(dataDirectory, 'reports.json');
const uploadsDirectory = path.join(dataDirectory, 'uploads');
const sessionsDirectory = path.join(dataDirectory, 'sessions');
const adminEmail = (process.env.ADMIN_EMAIL || (isProduction ? '' : 'admin@civicscope.local')).toLowerCase();
const adminPassword = process.env.ADMIN_PASSWORD || (isProduction ? '' : 'CivicScope!2026');
const sessionSecret = process.env.SESSION_SECRET || (isProduction ? '' : crypto.randomBytes(32).toString('hex'));

if (isProduction && (!adminEmail || adminPassword.length < 16 || !sessionSecret)) {
  throw new Error('Production requires ADMIN_EMAIL, an ADMIN_PASSWORD of at least 16 characters, and SESSION_SECRET.');
}

fs.mkdirSync(dataDirectory, { recursive: true });
fs.mkdirSync(sessionsDirectory, { recursive: true });

const uploadPhoto = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024, files: 1 },
  fileFilter: (_req, file, callback) => {
    const allowedTypes = ['image/jpeg', 'image/png', 'image/webp'];
    if (!allowedTypes.includes(file.mimetype)) return callback(new Error('Choose a JPG, PNG, or WebP photo.'));
    callback(null, true);
  }
});

app.use(express.json());
if (isProduction) app.set('trust proxy', 1);
app.use(session({
  store: new FileStore({ path: sessionsDirectory, ttl: 8 * 60 * 60, reapInterval: 3600, logFn: () => {} }),
  name: 'civicscope.sid',
  secret: sessionSecret,
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: 'lax', secure: isProduction, maxAge: 8 * 60 * 60 * 1000 }
}));
const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 10,
  standardHeaders: 'draft-8',
  legacyHeaders: false,
  message: { error: 'Too many sign-in attempts. Try again in 15 minutes.' }
});
const registrationLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  limit: 5,
  standardHeaders: 'draft-8',
  legacyHeaders: false,
  message: { error: 'Too many accounts created from this address. Try again later.' }
});

app.get('/healthz', (_req, res) => res.status(200).json({ status: 'ok' }));
app.use(express.static(path.join(__dirname, 'public')));

function readJson(filePath) {
  return JSON.parse(fs.readFileSync(filePath, 'utf8'));
}

function writeJson(filePath, value) {
  fs.writeFileSync(filePath, `${JSON.stringify(value, null, 2)}\n`);
}

if (!fs.existsSync(assetsPath)) writeJson(assetsPath, []);
if (!fs.existsSync(usersPath)) writeJson(usersPath, []);
if (!fs.existsSync(reportsPath)) writeJson(reportsPath, []);

function getImageType(buffer) {
  if (buffer.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]))) return { extension: 'png', mimeType: 'image/png' };
  if (buffer.length >= 3 && buffer[0] === 255 && buffer[1] === 216 && buffer[2] === 255) return { extension: 'jpg', mimeType: 'image/jpeg' };
  if (buffer.length >= 12 && buffer.toString('ascii', 0, 4) === 'RIFF' && buffer.toString('ascii', 8, 12) === 'WEBP') return { extension: 'webp', mimeType: 'image/webp' };
  return null;
}

function hashPassword(password, salt = crypto.randomBytes(16).toString('hex')) {
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${hash}`;
}

function verifyPassword(password, storedHash) {
  const [salt, expected] = storedHash.split(':');
  if (!salt || !expected) return false;
  const actual = crypto.scryptSync(password, salt, 64);
  const expectedBuffer = Buffer.from(expected, 'hex');
  return actual.length === expectedBuffer.length && crypto.timingSafeEqual(actual, expectedBuffer);
}

function requireRole(role) {
  return (req, res, next) => {
    if (!req.session.user) return res.status(401).json({ error: 'Please sign in first.' });
    if (role && req.session.user.role !== role) return res.status(403).json({ error: 'You do not have permission to do that.' });
    next();
  };
}

function establishSession(req, user) {
  return new Promise((resolve, reject) => {
    req.session.regenerate((error) => {
      if (error) return reject(error);
      req.session.user = user;
      req.session.save((saveError) => saveError ? reject(saveError) : resolve());
    });
  });
}

app.get('/api/session', (req, res) => {
  res.json({ user: req.session.user || null });
});

app.post('/api/auth/register', registrationLimiter, async (req, res) => {
  const name = typeof req.body.name === 'string' ? req.body.name.trim() : '';
  const email = typeof req.body.email === 'string' ? req.body.email.trim().toLowerCase() : '';
  const password = typeof req.body.password === 'string' ? req.body.password : '';
  if (name.length < 2 || name.length > 80) return res.status(400).json({ error: 'Enter a name between 2 and 80 characters.' });
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ error: 'Enter a valid email address.' });
  if (password.length < 8 || password.length > 200) return res.status(400).json({ error: 'Password must be at least 8 characters.' });

  const users = readJson(usersPath);
  if (email === adminEmail || users.some((user) => user.email === email)) {
    return res.status(409).json({ error: 'An account with that email already exists.' });
  }
  const user = {
    id: crypto.randomUUID(),
    name,
    email,
    passwordHash: hashPassword(password),
    role: 'public',
    createdAt: new Date().toISOString()
  };
  users.push(user);
  writeJson(usersPath, users);
  await establishSession(req, { id: user.id, name: user.name, email: user.email, role: user.role });
  res.status(201).json({ user: req.session.user });
});

app.post('/api/auth/login', loginLimiter, async (req, res) => {
  const email = typeof req.body.email === 'string' ? req.body.email.trim().toLowerCase() : '';
  const password = typeof req.body.password === 'string' ? req.body.password : '';
  const role = req.body.role;
  let user;

  if (role === 'admin' && email === adminEmail && password === adminPassword) {
    user = { id: 'admin', name: 'City administrator', email: adminEmail, role: 'admin' };
  } else if (role === 'public') {
    const account = readJson(usersPath).find((candidate) => candidate.email === email);
    if (account && verifyPassword(password, account.passwordHash)) {
      user = { id: account.id, name: account.name, email: account.email, role: 'public' };
    }
  }

  if (!user) return res.status(401).json({ error: 'Email or password is incorrect.' });
  await establishSession(req, user);
  res.json({ user: req.session.user });
});

app.post('/api/auth/logout', (req, res) => {
  req.session.destroy((error) => {
    if (error) return res.status(500).json({ error: 'Could not sign out.' });
    res.clearCookie('civicscope.sid');
    res.json({ success: true });
  });
});

app.get('/api/reports', requireRole(), (req, res) => {
  const reports = readJson(reportsPath);
  const visible = req.session.user.role === 'admin'
    ? reports
    : reports.filter((report) => report.reporterId === req.session.user.id);
  res.json({ data: visible, total: visible.length });
});

app.post('/api/reports', requireRole('public'), (req, res, next) => {
  uploadPhoto.single('photo')(req, res, (error) => {
    if (!error) return next();
    const message = error.code === 'LIMIT_FILE_SIZE' ? 'Photo must be 5 MB or smaller.' : error.message;
    res.status(400).json({ error: message });
  });
}, (req, res) => {
  const { title, category, location, description } = req.body;
  const allowedCategories = ['Road', 'Bridge', 'Water', 'Power', 'Other'];
  if (typeof title !== 'string' || title.trim().length < 4 || title.trim().length > 120) {
    return res.status(400).json({ error: 'Issue title must be between 4 and 120 characters.' });
  }
  if (!allowedCategories.includes(category)) return res.status(400).json({ error: 'Choose a valid issue category.' });
  if (typeof location !== 'string' || location.trim().length < 3 || location.trim().length > 160) {
    return res.status(400).json({ error: 'Location must be between 3 and 160 characters.' });
  }
  if (typeof description !== 'string' || description.trim().length < 10 || description.trim().length > 2000) {
    return res.status(400).json({ error: 'Description must be between 10 and 2,000 characters.' });
  }

  const imageType = req.file ? getImageType(req.file.buffer) : null;
  if (req.file && !imageType) return res.status(400).json({ error: 'The uploaded file is not a supported image.' });

  const reports = readJson(reportsPath);
  const reportId = `RPT-${crypto.randomBytes(3).toString('hex').toUpperCase()}`;
  const photoName = imageType ? `${crypto.randomBytes(16).toString('hex')}.${imageType.extension}` : null;
  if (photoName) {
    fs.mkdirSync(uploadsDirectory, { recursive: true });
    fs.writeFileSync(path.join(uploadsDirectory, photoName), req.file.buffer, { flag: 'wx' });
  }
  const report = {
    id: reportId,
    title: title.trim(),
    category,
    location: location.trim(),
    description: description.trim(),
    status: 'New',
    reporterId: req.session.user.id,
    reporterName: req.session.user.name,
    reporterEmail: req.session.user.email,
    photoName,
    photoType: imageType?.mimeType || null,
    submittedAt: new Date().toISOString()
  };
  reports.unshift(report);
  writeJson(reportsPath, reports);
  res.status(201).json({ data: report });
});

app.get('/api/reports/:id/photo', requireRole(), (req, res) => {
  const report = readJson(reportsPath).find((item) => item.id === req.params.id);
  if (!report) return res.status(404).json({ error: 'Report not found.' });
  if (req.session.user.role !== 'admin' && report.reporterId !== req.session.user.id) {
    return res.status(403).json({ error: 'You do not have permission to view this photo.' });
  }
  if (!report.photoName || !report.photoType) return res.status(404).json({ error: 'This report has no photo.' });
  const photoPath = path.join(uploadsDirectory, path.basename(report.photoName));
  if (!fs.existsSync(photoPath)) return res.status(404).json({ error: 'Photo file not found.' });
  res.set({ 'Content-Type': report.photoType, 'X-Content-Type-Options': 'nosniff', 'Cache-Control': 'private, no-store' });
  res.sendFile(photoPath);
});

app.patch('/api/reports/:id', requireRole('admin'), (req, res) => {
  const allowedStatuses = ['New', 'In progress', 'Resolved'];
  if (!allowedStatuses.includes(req.body.status)) return res.status(400).json({ error: 'Choose a valid report status.' });
  const reports = readJson(reportsPath);
  const report = reports.find((item) => item.id === req.params.id);
  if (!report) return res.status(404).json({ error: 'Report not found.' });
  report.status = req.body.status;
  report.updatedAt = new Date().toISOString();
  writeJson(reportsPath, reports);
  res.json({ data: report });
});

app.delete('/api/reports/:id', requireRole('admin'), (req, res) => {
  const reports = readJson(reportsPath);
  const reportIndex = reports.findIndex((item) => item.id === req.params.id);
  if (reportIndex === -1) return res.status(404).json({ error: 'Report not found.' });
  const [report] = reports.splice(reportIndex, 1);
  if (report.status !== 'Resolved') {
    return res.status(409).json({ error: 'Only resolved reports can be deleted.' });
  }

  writeJson(reportsPath, reports);
  if (report.photoName) {
    const photoPath = path.join(uploadsDirectory, path.basename(report.photoName));
    if (fs.existsSync(photoPath)) fs.unlinkSync(photoPath);
  }
  res.json({ success: true, id: report.id });
});

app.get('/api/assets', requireRole('admin'), (req, res) => {
  const { status, type, q } = req.query;
  let assets = readJson(assetsPath);

  if (status && status !== 'All statuses') {
    assets = assets.filter((asset) => asset.status.toLowerCase() === status.toLowerCase());
  }
  if (type && type !== 'All types') {
    assets = assets.filter((asset) => asset.type.toLowerCase() === type.toLowerCase());
  }
  if (q) {
    const query = q.toLowerCase();
    assets = assets.filter((asset) =>
      [asset.id, asset.name, asset.type, asset.location, asset.owner]
        .some((value) => value.toLowerCase().includes(query))
    );
  }

  res.json({ data: assets, total: assets.length });
});

app.get('/api/assets/:id', requireRole('admin'), (req, res) => {
  const asset = readJson(assetsPath).find((item) => item.id === req.params.id);
  if (!asset) return res.status(404).json({ error: 'Asset not found' });
  res.json({ data: asset });
});

app.get('/api/summary', requireRole('admin'), (_req, res) => {
  const assets = readJson(assetsPath);
  const critical = assets.filter((asset) => asset.status === 'Critical').length;
  const atRisk = assets.filter((asset) => asset.status === 'At risk').length;
  const averageCondition = assets.length
    ? Math.round(assets.reduce((sum, asset) => sum + asset.condition, 0) / assets.length)
    : 0;
  res.json({
    totalAssets: assets.length,
    critical,
    atRisk,
    good: assets.length - critical - atRisk,
    averageCondition,
    inspectionsDue: assets.filter((asset) => asset.nextInspection <= '2026-11-30').length
  });
});

app.listen(PORT, () => {
  console.log(`Infrastructure monitor running at http://localhost:${PORT}`);
});
