# CivicScope: Public Infrastructure Asset Monitor

A starter full-stack dashboard for tracking public infrastructure assets. The browser dashboard is served by the same Express app as the JSON API, so there is no separate frontend build step.

## Requirements

- Node.js 18 or later
- npm

## Run locally

1. Open a terminal in this project folder.
2. Install dependencies:

   ```powershell
   npm install
   ```

3. Start the server:

   ```powershell
   npm start
   ```

4. Open [http://localhost:3000](http://localhost:3000).

For automatic server restarts during development, use `npm run dev`.

## Deploy to Render

The repository includes `render.yaml` for a single-instance Node web service. The Blueprint attaches a 1 GB persistent disk for accounts, reports, photos, and sessions. Render requires a paid web-service plan for persistent disks; review the current price in Render before creating the service. This configuration is not provisioned automatically.

1. Push this project to a GitHub repository. The `.gitignore` excludes local accounts, reports, photos, and sessions; do not remove those exclusions.
2. In Render, choose **New → Blueprint**, connect the repository, and select `render.yaml`.
3. When prompted, enter the administrator email and a unique password of at least 16 characters. Render generates `SESSION_SECRET`.
4. Review the paid service and disk costs, then create the Blueprint. Render will provide the public `onrender.com` URL after deployment.

Do not commit passwords or session secrets. Keep the Render service at one instance while using its attached disk. The app persists application records on that disk; keep backups of real resident reports and photos.

## Logins

- **Public:** choose **Public access**, create an account with an email and password, then submit and track issue reports.
- **Administrator:** choose **Administrator** to review all resident reports and update their status, alongside the infrastructure dashboard.

Demo admin credentials:

- Email: `admin@civicscope.local`
- Password: `CivicScope!2026`

Set `ADMIN_EMAIL` and `ADMIN_PASSWORD` environment variables to change the local demo administrator credentials. In production, the server refuses to start without an admin email, a unique 16-character-or-longer admin password, and `SESSION_SECRET`.

## API

- `GET /api/assets` returns all assets. Optional query parameters: `type`, `status`, and `q`.
- `GET /api/assets/:id` returns one asset by ID.
- `GET /api/summary` returns counts and average condition.
- `POST /api/auth/register`, `POST /api/auth/login`, and `POST /api/auth/logout` manage user sessions.
- `GET /api/reports` returns the signed-in user's reports or all reports for administrators.
- `POST /api/reports` submits a public issue with an optional JPG, PNG, or WebP photo (up to 5 MB); `PATCH /api/reports/:id` updates its status for administrators.
- `GET /api/reports/:id/photo` serves a report photo only to its reporter or an administrator.
- `DELETE /api/reports/:id` lets administrators permanently remove resolved reports and their attached photos.

Asset data is in `data/assets.json`; public accounts, reports, uploaded photos, and sessions are stored in the configured data directory. Local private data is excluded from the source ZIP and version control; the server creates empty stores on first run. Render supplies HTTPS, and this configuration uses persistent file-backed sessions, sign-in/registration rate limits, and a persistent disk. Review access controls, backups, retention requirements, and security practices before using real municipal data.
